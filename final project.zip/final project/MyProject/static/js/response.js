const responseObj = {
  hello: `Hey ! How are you ?`,
  hey: "Hey! What's Up",
  ok:"Stay Healthy",
  thankyou:"welcome",
  fever:"How much degree temp of your body",

  today: new Date().toDateString(),
  time: new Date().toLocaleTimeString(),
};
